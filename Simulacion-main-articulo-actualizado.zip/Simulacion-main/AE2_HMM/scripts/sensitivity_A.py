"""Analisis de sensibilidad a especificacion de la matriz de transicion A.

Datos sinteticos: todas las secuencias se generan con el HMM nominal.
Se decodifican las mismas observaciones usando A nominal, A con mayor
persistencia y A con menor persistencia. Semilla maestra 20261112.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.hmm_model import HMM, DEFAULT_TRANSITION_MATRIX, DEFAULT_EMISSION_MATRIX, DEFAULT_INITIAL_PROBABILITIES
from src.simulation import macro_f1_score, summarize, holm_bonferroni

T, N, SEED = 500, 500, 20261112
A0 = DEFAULT_TRANSITION_MATRIX.copy()
I = np.eye(3)
U = np.full((3, 3), 1/3)
# Perturbaciones convexas: preservan filas estocasticas y no generan negativos.
MATRICES = {
    "A_nominal": A0,
    "A_mayor_persistencia": 0.20 * A0 + 0.80 * I,
    "A_menor_persistencia": 0.20 * A0 + 0.80 * U,
}

rng_master = np.random.SeedSequence(SEED)
child_seeds = rng_master.spawn(N)
values = {k: np.empty(N) for k in MATRICES}
for r, ss in enumerate(child_seeds):
    # Simulacion de referencia: siempre con parametros nominales.
    generated = HMM(A0, DEFAULT_EMISSION_MATRIX, DEFAULT_INITIAL_PROBABILITIES).simulate(
        T, rng=np.random.default_rng(ss)
    )
    truth, obs = generated["states"], generated["observations"]
    for name, A in MATRICES.items():
        decoder = HMM(A, DEFAULT_EMISSION_MATRIX, DEFAULT_INITIAL_PROBABILITIES)
        pred = decoder.viterbi(obs)
        values[name][r] = macro_f1_score(truth, pred)

summaries = {name: summarize(x) for name, x in values.items()}
comparisons = {}
raw = []
for name in ("A_mayor_persistencia", "A_menor_persistencia"):
    d = values[name] - values["A_nominal"]
    test = wilcoxon(d, alternative="two-sided", zero_method="wilcox") if np.any(d) else None
    p = float(test.pvalue) if test else 1.0
    comparisons[name] = {
        "mean_difference_vs_nominal": float(np.mean(d)),
        "median_difference_vs_nominal": float(np.median(d)),
        "wilcoxon_statistic": float(test.statistic) if test else 0.0,
        "p_value_raw": p,
        "n_positive": int(np.sum(d > 0)),
        "n_negative": int(np.sum(d < 0)),
        "n_ties": int(np.sum(d == 0)),
    }
    raw.append(p)
for name, p_adj in zip(comparisons, holm_bonferroni(raw)):
    comparisons[name]["p_value_holm"] = p_adj

out = ROOT / "outputs"
out.mkdir(exist_ok=True)
rows=[]
for name, stats in summaries.items():
    rows.append({"scenario":name, **stats})
pd.DataFrame(rows).to_csv(out/"sensibilidad_A_metricas.csv", index=False)
pd.DataFrame([{"scenario":k, **v} for k,v in comparisons.items()]).to_csv(out/"sensibilidad_A_contrastes.csv", index=False)
(out/"sensibilidad_A_resumen.json").write_text(json.dumps({
    "metadata":{"T":T,"N":N,"seed":SEED,"generation":"A, B y pi nominales","decoder":"Viterbi con A alternativa, B y pi nominales"},
    "matrices":{k:v.tolist() for k,v in MATRICES.items()},
    "metrics":summaries,"comparisons":comparisons,
}, indent=2, ensure_ascii=False), encoding="utf-8")

fig, ax = plt.subplots(figsize=(8,5))
labels=["A nominal", "A más persistente", "A menos persistente"]
series=[values[k] for k in MATRICES]
ax.boxplot(series, tick_labels=labels, showmeans=True)
ax.set_ylabel("Macro-F1 por secuencia")
ax.set_title("Sensibilidad del decodificador a la matriz de transición A")
ax.grid(axis="y", alpha=.25)
fig.tight_layout()
fig.savefig(out/"sensibilidad_A_300dpi.png", dpi=300, bbox_inches="tight")
plt.close(fig)

print(json.dumps({"metrics":summaries,"comparisons":comparisons}, indent=2))
