# Referencias académicas recientes añadidas al manuscrito

Se incorporaron **12 artículos revisados por pares publicados entre 2021 y 2025** para ampliar el estado del arte en HMM ecológicos, procesos parcialmente observados, series ambientales y peligro de incendios. Los DOI y datos bibliográficos se contrastaron con páginas editoriales, PubMed/USGS o repositorios institucionales. Esta comprobación bibliográfica **no equivale** a certificar que cada título esté indexado en Scopus o Web of Science; el equipo debe comprobar esa condición en las bases institucionales y guardar la evidencia.

## Referencias en estilo IEEE

[1] R. Glennie, T. Adam, V. Leos-Barajas, T. Michelot, T. Photopoulou, and B. T. McClintock, “Hidden Markov models: Pitfalls and opportunities in ecology,” *Methods in Ecology and Evolution*, vol. 14, no. 1, pp. 43–56, 2023. doi: [10.1111/2041-210X.13801](https://doi.org/10.1111/2041-210X.13801). Publicación en línea: 2022.

[2] K. Vitense, M. A. Hanson, B. R. Herwig, K. D. Zimmer, J. Fieberg, and T. Siqueira, “Using hidden Markov models to inform conservation and management strategies in ecosystems exhibiting alternative stable states,” *Journal of Applied Ecology*, vol. 58, no. 5, pp. 1069–1078, 2021. doi: [10.1111/1365-2664.13855](https://doi.org/10.1111/1365-2664.13855).

[3] T. A. Gowan, M. D. Tringali, J. A. Hostetler, J. Martin, L. I. Ward-Geiger, and J. M. Johnson, “A hidden Markov model for estimating age-specific survival when age and size are uncertain,” *Ecology*, vol. 102, no. 8, Art. no. e03426, 2021. doi: [10.1002/ecy.3426](https://doi.org/10.1002/ecy.3426).

[4] B. T. McClintock, “Worth the effort? A practical examination of random effects in hidden Markov models for animal telemetry data,” *Methods in Ecology and Evolution*, vol. 12, no. 8, pp. 1475–1497, 2021. doi: [10.1111/2041-210X.13619](https://doi.org/10.1111/2041-210X.13619).

[5] S. Nicol, M.-J. Cros, N. Peyrard, R. Sabbadin, R. Trépos, R. A. Fuller, and B. K. Woodworth, “FlywayNet: A hidden semi-Markov model for inferring the structure of migratory bird networks from count data,” *Methods in Ecology and Evolution*, vol. 14, pp. 265–279, 2023. doi: [10.1111/2041-210X.14011](https://doi.org/10.1111/2041-210X.14011).

[6] D. Esguerra and S. B. Munch, “Accounting for observation noise in equation-free forecasting: The hidden-Markov S-map,” *Methods in Ecology and Evolution*, vol. 15, no. 8, pp. 1347–1359, 2024. doi: [10.1111/2041-210X.14337](https://doi.org/10.1111/2041-210X.14337).

[7] Z. R. Rand, E. J. Ward, J. E. Zamon, T. P. Good, and C. J. Harvey, “Using hidden Markov models to develop ecosystem indicators from non-stationary time series,” *Ecological Modelling*, vol. 495, Art. no. 110800, 2024. doi: [10.1016/j.ecolmodel.2024.110800](https://doi.org/10.1016/j.ecolmodel.2024.110800).

[8] S. Kondylatos, I. Prapas, M. Ronco, I. Papoutsis, G. Camps-Valls, M. Piles, M.-Á. Fernández-Torres, and N. Carvalhais, “Wildfire danger prediction and understanding with deep learning,” *Geophysical Research Letters*, vol. 49, no. 17, Art. no. e2022GL099368, 2022. doi: [10.1029/2022GL099368](https://doi.org/10.1029/2022GL099368).

[9] M. C. Iban and A. Sekertekin, “Machine learning based wildfire susceptibility mapping using remotely sensed fire data and GIS: A case study of Adana and Mersin provinces, Turkey,” *Ecological Informatics*, Art. no. 101647, 2022. doi: [10.1016/j.ecoinf.2022.101647](https://doi.org/10.1016/j.ecoinf.2022.101647).

[10] J. R. McNorton, F. Di Giuseppe, E. Pinnington, M. Chantry, and C. Barnard, “A global probability-of-fire (PoF) forecast,” *Geophysical Research Letters*, vol. 51, no. 12, Art. no. e2023GL107929, 2024. doi: [10.1029/2023GL107929](https://doi.org/10.1029/2023GL107929).

[11] I. Zacharakis and V. A. Tsihrintzis, “Development of an integrated wildfire danger rating system for pre-fire planning and incident forecasting,” *International Journal of Disaster Risk Reduction*, vol. 116, Art. no. 105111, 2025. doi: [10.1016/j.ijdrr.2024.105111](https://doi.org/10.1016/j.ijdrr.2024.105111).

[12] O. Mirones, J. Baño-Medina, S. Brands, and J. Bedia, “Toward spatio-temporally consistent multi-site fire danger downscaling with explainable deep learning,” *Journal of Geophysical Research: Machine Learning and Computation*, vol. 2, no. 1, Art. no. e2024JH000331, 2025. doi: [10.1029/2024JH000331](https://doi.org/10.1029/2024JH000331).

## Cómo se integran en el artículo

- HMM ecológicos y estructura temporal: [1]–[5].
- Ruido de observación y series ambientales no estacionarias: [6]–[7].
- Predicción y susceptibilidad de incendios: [8]–[12].

## Pendiente de verificación institucional

1. Consultar cada DOI por título en Scopus y Web of Science mediante el acceso institucional.
2. Registrar para cada registro: base consultada, fecha, título, DOI, fuente y resultado de indexación.
3. Conservar exportaciones o capturas de los resultados.
4. No afirmar “12 artículos Scopus/WoS” hasta completar esta comprobación.

El artículo también conserva las dos referencias clásicas de Rabiner (1989) y Baum et al. (1970), que fundamentan los algoritmos HMM.
