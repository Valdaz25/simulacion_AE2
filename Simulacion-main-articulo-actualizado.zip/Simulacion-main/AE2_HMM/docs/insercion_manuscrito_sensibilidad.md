# Texto listo para incorporar al manuscrito

## Sub-sección sugerida en Metodología: análisis de sensibilidad de A

Como análisis complementario se evaluó la sensibilidad de la decodificación ante una especificación alternativa de la matriz de transición. Se generaron 500 secuencias de longitud 500 con los parámetros nominales del HMM y semilla maestra 20261112. Para cada secuencia se aplicó Viterbi sobre las mismas observaciones usando (i) la matriz nominal, (ii) una matriz con mayor persistencia, definida como \(A_{+}=0.20A_0+0.80I\), y (iii) una matriz con menor persistencia, definida como \(A_{-}=0.20A_0+0.80U\), donde cada fila de \(U\) es uniforme. Se mantuvieron constantes la matriz de emisión \(B\) y la distribución inicial \(\pi\). El diseño es pareado porque cada alternativa se evalúa sobre las mismas secuencias latentes y observadas.

## Sub-sección sugerida en Resultados

La Macro-F1 media del decodificador nominal fue 0.6583 (DE = 0.0273; IC percentil 95 % [0.6042, 0.7130]). Al usar la matriz de mayor persistencia, la media descendió a 0.5315 (DE = 0.0437; IC 95 % [0.4364, 0.6076]); la diferencia media pareada frente al caso nominal fue −0.1268 y las 500 réplicas presentaron una diferencia negativa (Wilcoxon bilateral con ajuste Holm: p = 2.53 × 10⁻⁸³). Con la matriz de menor persistencia, la Macro-F1 media fue 0.6590 (DE = 0.0218; IC 95 % [0.6143, 0.7018]); la diferencia media frente al nominal fue 0.0007 y no se detectó diferencia estadísticamente significativa (p ajustado = 0.4527).

## Sub-sección sugerida en Discusión

La perturbación de la matriz de transición produjo un efecto asimétrico. La imposición de una persistencia elevada, muy superior a la del proceso generador, redujo de manera consistente la calidad de la decodificación. En cambio, la matriz de menor persistencia no produjo una diferencia media relevante. Este resultado indica que el decodificador puede ser sensible a una especificación excesivamente persistente de la dinámica latente. Sin embargo, la conclusión está restringida al diseño sintético, las matrices seleccionadas y la longitud de secuencia evaluada; no permite inferir el comportamiento de un sistema de alerta de incendios real.

## Respuesta revisada a P3

El modelo es reproducible bajo semillas y parámetros documentados. Su sensibilidad no es uniforme: la matriz de transición con persistencia aumentada redujo la Macro-F1 media en 0.1268, mientras que la perturbación hacia transiciones más uniformes produjo una diferencia media de 0.0007 sin evidencia estadística de cambio. La conclusión se limita a las condiciones simuladas y requiere validación posterior con series ambientales reales.

**Nota:** insertar la figura `outputs/sensibilidad_A_300dpi.png` y citarla como Figura adicional o Figura 4, según la numeración definitiva. Los resultados no se han incorporado todavía al PDF existente.
