# Guion actualizado del pitch (2:30)

**Bloque 1 – Gancho (0:00–0:15)**  
“Imaginen un bosque donde solo podemos observar señales indirectas, como humedad alta, media o baja. El nivel de riesgo permanece oculto. ¿Podemos inferir sus cambios usando un modelo probabilístico?”

**Bloque 2 – Motivación (0:15–0:32)**  
“Antes de pensar en una alerta real, debemos estudiar qué tan confiable es el modelo cuando cambian sus supuestos. Por eso analizamos tanto el ruido de las observaciones como la matriz que gobierna las transiciones entre estados.”

**Bloque 3 – Solución (0:32–0:52)**  
“Proponemos un Modelo Oculto de Markov discreto con tres estados latentes de riesgo y tres observaciones ordinales de humedad. El modelo se define mediante la distribución inicial pi, la matriz de transición A y la matriz de emisión B. Para inferir la secuencia oculta utilizamos el algoritmo de Viterbi.”

**Bloque 4 – Metodología (0:52–1:14)**  
“Primero comparamos tres condiciones: Viterbi nominal, un clasificador sin memoria y Viterbi con observaciones degradadas. Después ejecutamos un análisis adicional de sensibilidad: generamos secuencias con parámetros nominales y cambiamos únicamente la matriz A usada por el decodificador. Todas las pruebas usan semillas fijas.”

**Bloque 5 – Resultados (1:14–1:43)**  
“En el experimento principal, la Macro-F1 fue 0.6602 para Viterbi nominal, 0.6603 para el baseline sin memoria y 0.4989 con emisiones degradadas. En sensibilidad, aumentar fuertemente la persistencia de A redujo la Macro-F1 de 0.6583 a 0.5315; reducir la persistencia no produjo un cambio significativo.”

**Bloque 6 – Aporte (1:43–2:08)**  
“El aporte es mostrar, en un entorno controlado, que la estructura temporal no garantiza por sí sola una mejora y que una matriz de transición mal especificada puede afectar la inferencia. El código, las semillas, las pruebas y los resultados están disponibles para reproducir el experimento.”

**Bloque 7 – Cierre (2:08–2:30)**  
“Respondemos así: el problema puede representarse mediante un HMM discreto; los parámetros y la calidad de las observaciones influyen en los resultados; y la reproducibilidad es posible, aunque la sensibilidad depende de cómo se alteren las transiciones. Este estudio es una simulación metodológica, no un predictor validado de incendios reales. El siguiente paso es validar el modelo con datos ambientales observados. Gracias.”

**Producción:** mostrar `outputs/fig_metricas_300dpi.png` y `outputs/sensibilidad_A_300dpi.png`; mantener en pantalla la etiqueta “Datos simulados”. Exportar MP4 horizontal 1920×1080. El archivo es un guion, no una grabación.
