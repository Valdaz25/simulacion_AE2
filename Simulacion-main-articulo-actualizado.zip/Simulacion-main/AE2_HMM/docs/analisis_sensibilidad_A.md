# Análisis complementario de sensibilidad a la matriz de transición A

## Propósito

Se evaluó cuánto cambia la decodificación cuando el modelo utilizado por Viterbi especifica una matriz de transición distinta de la que generó los datos. Las secuencias se generaron siempre con el HMM nominal (A, B y π nominales); posteriormente, las mismas observaciones se decodificaron con tres matrices alternativas. Este diseño aísla el efecto de una especificación incorrecta de A y conserva la comparación pareada.

## Diseño reproducible

- Longitud de secuencia: T = 500.
- Réplicas independientes: N = 500.
- Semilla maestra: 20261112, con `numpy.random.SeedSequence(20261112).spawn(500)`.
- Generador: HMM nominal, con A, B y π del modelo original.
- Decodificador: Viterbi, manteniendo B y π nominales y cambiando únicamente A.
- A nominal:

\[
A_0=\begin{bmatrix}0.70&0.25&0.05\\0.30&0.50&0.20\\0.10&0.30&0.60\end{bmatrix}.
\]

- A de mayor persistencia: \(A_{+}=0.20A_0+0.80I\).
- A de menor persistencia: \(A_{-}=0.20A_0+0.80U\), donde cada fila de U es uniforme (1/3, 1/3, 1/3).

Las dos matrices alternativas son combinaciones convexas de matrices estocásticas; por ello conservan entradas no negativas y sumas por fila iguales a uno. La generación permanece nominal para representar un caso de desajuste entre el proceso generador y el modelo de inferencia.

## Resultados

| Especificación de A en Viterbi | Media Macro-F1 | DE | Mínimo | Máximo | IC percentil 95 % |
|---|---:|---:|---:|---:|---:|
| Nominal | 0.6583 | 0.0273 | 0.5736 | 0.7451 | [0.6042, 0.7130] |
| Mayor persistencia | 0.5315 | 0.0437 | 0.3431 | 0.6357 | [0.4364, 0.6076] |
| Menor persistencia | 0.6590 | 0.0218 | 0.5699 | 0.7133 | [0.6143, 0.7018] |

Comparaciones pareadas contra A nominal (Wilcoxon bilateral; corrección Holm para dos contrastes):

| Contraste | Diferencia media | p ajustado Holm | Réplicas a favor del alternativo | Réplicas en contra | Empates |
|---|---:|---:|---:|---:|---:|
| Mayor persistencia − nominal | −0.1268 | 2.53 × 10⁻⁸³ | 0 | 500 | 0 |
| Menor persistencia − nominal | +0.0007 | 0.4527 | 258 | 242 | 0 |

## Interpretación

En este experimento sintético, imponer una persistencia mucho mayor que la del proceso generador redujo la Macro-F1 media en aproximadamente 0.1268. La degradación fue consistente en las 500 réplicas. En cambio, la especificación de menor persistencia produjo una diferencia media prácticamente nula y no se detectó evidencia estadística de diferencia frente al modelo nominal (p ajustado = 0.4527).

El resultado muestra una sensibilidad asimétrica: el exceso de persistencia perjudicó la decodificación en este diseño, mientras que la perturbación hacia transiciones más uniformes no produjo un cambio detectable. No debe generalizarse a datos forestales reales ni interpretarse como estimación de la dinámica de incendios. Los estados y observaciones son categorías sintéticas; no se utilizaron registros meteorológicos, satelitales ni históricos de incendios.

## Respuesta complementaria a P3

La reproducibilidad computacional se mantiene al fijar semilla, número de réplicas, longitud de secuencia y transformaciones de A. La sensibilidad depende de la dirección de la perturbación: la matriz con mayor persistencia generó una caída clara de desempeño, mientras que la matriz con menor persistencia tuvo un efecto medio despreciable. Por tanto, P3 recibe una respuesta condicionada al escenario simulado y no una afirmación universal sobre HMM ambientales.

## Archivos generados

- `scripts/sensitivity_A.py`: experimento reproducible.
- `outputs/sensibilidad_A_metricas.csv`: resumen estadístico por escenario.
- `outputs/sensibilidad_A_contrastes.csv`: contrastes pareados.
- `outputs/sensibilidad_A_resumen.json`: parámetros, matrices y resultados completos.
- `outputs/sensibilidad_A_300dpi.png`: figura de sensibilidad a 300 dpi.

Ejecución desde `AE2_HMM/`:

```bash
python scripts/sensitivity_A.py
```

**Nota editorial:** estos resultados son complementarios y no están incorporados automáticamente en `manuscrito_final.pdf`. Antes de entregar, debe actualizarse el archivo LaTeX y recompilar el PDF, conservando la trazabilidad entre el código, las tablas y el documento.
